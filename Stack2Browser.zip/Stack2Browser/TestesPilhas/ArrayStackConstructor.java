
import static org.junit.Assert.*;

import org.junit.Test;


public class ArrayStackConstructor {

	private ArrayStack<String> teste;

	@Test
	public void testArrayStack1() {
		
		teste = new ArrayStack<String>();
		
		assertTrue(teste != null);
	}


	@Test
	public void testArrayStack2() {
		
		teste = new ArrayStack<String>();
		
		assertTrue(teste.isEmpty());
	}
	
	@Test
	public void testArrayStack3() {
		
		teste = new ArrayStack<String>();
		
		assertTrue(teste.capacity() == 10);
	}


}
