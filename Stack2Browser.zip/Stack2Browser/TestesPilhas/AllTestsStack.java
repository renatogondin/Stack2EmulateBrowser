import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({  
	ArrayStackIsEqualTest.class,
	ArrayStackClearTest.class,
	ArrayStackIsEqualTest.class,
	ArrayStackConstructor2.class,
	ArrayStackConstructor.class,
	ArrayStackIsEmptyTest.class,
	ArrayStackPeekTest.class,
	ArrayStackPopTest.class,
	ArrayStackPushTest.class,
	ArrayStackSizeTest.class,
	ArrayStackToStringTest.class,
	
})

public class AllTestsStack {

}