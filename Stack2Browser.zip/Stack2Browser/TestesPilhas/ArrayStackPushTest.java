import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayStackPushTest {

	private ArrayStack<String> teste;
	private String expected;
	private String actual;

	@Test
	public void test1() {
		
		teste = new ArrayStack<String>();
		expected = "s";
		teste.push("s");
		
		actual = teste.peek();
		
		assertEquals(expected, actual);
		
	}
	
	@Test
	public void test2() {
		
		teste = new ArrayStack<String>();
		expected = "s";
		teste.push("s");
		
		actual = teste.peek();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test4() {
		
		teste = new ArrayStack<String>();
		expected = "s\na\n";
		
		teste.push("a");
		teste.push("s");
		
		actual = teste.toString();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test5() {
		
		teste = new ArrayStack<String>();
		expected = "t";
		
		teste.push("a");
		teste.push("s");
		teste.push("t");
		
		actual = teste.peek();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test6() {
		
		teste = new ArrayStack<String>(3);
		expected = "x\n"
				+ "t\n"
				+ "s\n";
		
		teste.push("a");
		teste.push("s");
		teste.push("t");
		teste.push("x");

		
		actual = teste.toString();
		
		assertEquals(expected, actual);
	}

	
}
