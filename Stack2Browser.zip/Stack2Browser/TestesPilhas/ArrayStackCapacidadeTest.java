
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class ArrayStackCapacidadeTest {

	private int expected;
	private int actual;


	@Test
	public void test1() {
		
		ArrayStack<String> xpto = new ArrayStack<String>();
		expected = xpto.capacity();
		actual = 10;

		assertEquals("devem ser iguais",expected,actual);
	}
	
	@Test
	public void test2() {
		
		ArrayStack<String> xpto = new ArrayStack<String>(5);
		expected = xpto.capacity();
		actual = 5;

		assertEquals("devem ser iguais",expected,actual);
	}
	
	@Test
	public void test3() {
		
		ArrayStack<String> xpto = new ArrayStack<String>();
		xpto.clear();
		expected = xpto.capacity();
		actual = 10;

		assertEquals("devem ser iguais",expected,actual);
	}
	
	@Test
	public void test4() {
		
		ArrayStack<String> xpto = new ArrayStack<String>();
		xpto.clear();
		xpto.push("s");
		expected = xpto.capacity();
		actual = 10;

		assertEquals("devem ser iguais",expected,actual);
	}
	
}
