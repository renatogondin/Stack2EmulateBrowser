import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayStackPopTest {

	private ArrayStack<String> teste;
	private String expected;
	private String actual;

	@Test
	public void test1() {
		
		teste = new ArrayStack<String>();
		expected = null;
		actual = teste.pop();
		
		assertEquals(expected, actual);
		
	}
	
	@Test
	public void test2() {
		
		teste = new ArrayStack<String>();
		expected = null;
		
		teste.push("s");
		teste.clear();
		
		actual = teste.pop();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test3() {
		
		teste = new ArrayStack<String>();
		expected = "s";
		
		teste.push("s");
		
		actual = teste.pop();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test4() {
		
		teste = new ArrayStack<String>();
		expected = "s";
		
		teste.push("a");
		teste.push("s");
		
		actual = teste.pop();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test5() {
		
		teste = new ArrayStack<String>();
		expected = "a";
		
		teste.push("a");
		teste.push("s");
		teste.pop();
		
		actual = teste.pop();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test6() {
		
		teste = new ArrayStack<String>(3);
		expected = null;
		
		teste.push("a");
		teste.push("s");
		teste.push("t");
		teste.push("x");
		teste.pop();
		teste.pop();
		teste.pop();
		
		actual = teste.pop();
		
		assertEquals(expected, actual);
	}

	
}
