
import static org.junit.Assert.*;

import org.junit.Test;


public class ArrayStackConstructor2 {

	private ArrayStack<String> teste;

	@Test
	public void testArrayStack1() {
		
		teste = new ArrayStack<String>(5);
		
		assertTrue(teste != null);
	}


	@Test
	public void testArrayStack2() {
		
		teste = new ArrayStack<String>(5);
		
		assertTrue(teste.isEmpty());
	}
	
	@Test
	public void testArrayStack3() {
		
		teste = new ArrayStack<String>(5);
		
		assertEquals(teste.capacity(), 5);
	}


}
