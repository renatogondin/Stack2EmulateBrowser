import static org.junit.Assert.*;

import org.junit.Test;

public class ArrayStackIsEmptyTest {

	
	private ArrayStack<String> teste;
	
	private boolean expected;
	private boolean actual;


	@Test
	public void test1() {
		
		teste = new ArrayStack<String>();
		
		expected = true;
		actual = teste.isEmpty();
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test2() {
		
		teste = new ArrayStack<String>(5);
		
		expected = true;
		actual = teste.isEmpty();
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test3() {
		
		teste = new ArrayStack<String>();
		
		expected = false;
		teste.push("s");
		actual = teste.isEmpty();
		
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test4() {
		
		teste = new ArrayStack<String>();
		
		expected = true;
		teste.push("s");
		teste.clear();
		actual = teste.isEmpty();
		
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test5() {
		
		teste = new ArrayStack<String>(3);
		
		expected = false;
		teste.push("s");
		teste.push("s1");
		actual = teste.isEmpty();;
		
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test6() {
		
		teste = new ArrayStack<String>();
		
		expected = false;
		teste.push("s");
		teste.push("s1");
		teste.pop();
		actual = teste.isEmpty();;
		
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test7() {
		
		teste = new ArrayStack<String>(3);
		
		expected = false;
		teste.push("s");
		teste.push("s1");
		teste.push("s2");
		actual = teste.isEmpty();;
		
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test8() {
		
		teste = new ArrayStack<String>(3);
		
		expected = false;
		teste.push("s");
		teste.push("s1");
		teste.push("s2");
		teste.push("s3");
		actual = teste.isEmpty();
		
		
		assertEquals(expected,actual);
	}
	
	@Test
	public void test9() {
		
		teste = new ArrayStack<String>(3);
		
		expected = false;
		teste.push("s");
		teste.push("s1");
		teste.push("s2");
		teste.push("s3");
		teste.pop();
		actual = teste.isEmpty();
		
		
		assertEquals(expected,actual);
	}

}
