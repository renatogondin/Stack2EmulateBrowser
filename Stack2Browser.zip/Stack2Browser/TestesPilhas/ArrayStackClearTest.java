
import static org.junit.Assert.assertEquals;

import org.junit.Test;


public class ArrayStackClearTest {

	private ArrayStack<String> teste;


	@Test
	public void test1() {
		
		teste = new ArrayStack<String>();
		
		assertEquals(teste.capacity(),10);
	}
	
	@Test
	public void test2() {
		
		teste = new ArrayStack<String>(3);
		
		assertEquals(teste.capacity(),3);
	}


}
