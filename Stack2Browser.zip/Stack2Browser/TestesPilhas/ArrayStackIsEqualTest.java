
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ArrayStackIsEqualTest {

	private ArrayStack<String> expected;
	private ArrayStack<String> actual;


	@Test
	public void test1() {
		
		expected = new ArrayStack<String>();
		actual = new ArrayStack<String>();
		actual.clear();

		assertTrue("deveria estar vazia",expected.isEqual(actual));
	}
	
	@Test
	public void test2() {
		
		expected = new ArrayStack<String>();
		actual = new ArrayStack<String>();
		actual.push("s");
		actual.clear();
		
		assertTrue("deveria estar vazia", expected.isEqual(actual));
	}
	
	@Test
	public void test3() {
		
		expected = new ArrayStack<String>();
		actual = new ArrayStack<String>();
		actual.push("s");
		actual.push("r");
		actual.clear();
		
		assertTrue("deveria estar vazia", expected.isEqual(actual));
	}
	
	@Test
	public void test4() {
		
		expected = new ArrayStack<String>();
		expected.push("s");
		actual = new ArrayStack<String>();
		actual.push("s");
		actual.push("r");
		actual.clear();
		actual.push("s");
		
		assertTrue("devera conter apenas s", expected.isEqual(actual));
	}
	
	@Test
	public void test5() {
		
		expected = new ArrayStack<String>();
		expected.push("s");
		actual = new ArrayStack<String>();
		actual.push("s");
		actual.push("r");
		actual.clear();
		
		
		assertTrue("deveriam ser diferentes", !expected.isEqual(actual));
	}
	
	@Test
	public void test6() {
		
		expected = new ArrayStack<String>();
		expected.push("s");
		actual = new ArrayStack<String>();
		actual.push("s");
		actual.push("r");
		actual.clear();
		actual.push("s");
		
		assertTrue("deveriam ser iguais", expected.isEqual(actual));
	}
	

}
