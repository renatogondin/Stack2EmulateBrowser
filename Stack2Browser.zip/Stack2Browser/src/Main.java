
public class Main {

	public static void main(String[] args) {


		//Accoes
		Action put = Action.PUT;
		Action get = Action.GET;
		Action post = Action.POST;
		Action delete = Action.DELETE;

		//Dominios
		String domain1 = "www.univA.com";
		String domain2 = "www.univB.com";
		String domain3 = "www.univC.com";


		//Recursos
		String resource1 = "horasSecs";
		String resource2 = "horasLabs";
		String resource3 = "horasBar";
		String resource4 = "horasBiblio";

		BackForwardManager historic =  new BackForwardManager(6);


		System.out.println("As pilhas inicialmente estão vazias?\n");

		System.out.println("Back: \n" + historic.listBackAll());

		System.out.println("Forward: \n" + historic.listForwardAll());


		RestAction  visitD1R1 = new RestAction(put, domain1, resource1);
		RestAction  visitD1R2 = new RestAction(get, domain1, resource2);
		RestAction  visitD1R3 = new RestAction(post, domain1, resource3);
		RestAction  visitD1R4 = new RestAction(delete, domain1, resource4);


		RestAction  visitD2R1 = new RestAction(put, domain2, resource1);
		RestAction  visitD2R2 = new RestAction(get, domain2, resource2);
		RestAction  visitD2R3 = new RestAction(post, domain2, resource3);
		RestAction  visitD2R4 = new RestAction(delete, domain2, resource4);

		RestAction  visitD3R1 = new RestAction(put, domain3, resource1);
		RestAction  visitD3R2 = new RestAction(get, domain3, resource2);
		RestAction  visitD3R3 = new RestAction(post, domain3, resource3);

		//Fazem-se 8 accoes REST
		goToResource(visitD1R1, historic);
		goToResource(visitD1R2, historic);
		goToResource(visitD1R3, historic);
		goToResource(visitD1R4, historic);
		goToResource(visitD2R1, historic);
		goToResource(visitD2R2, historic);
		goToResource(visitD2R3, historic);
		goToResource(visitD2R4, historic);

		System.out.println("As pilhas depois das 8 accoes iniciais:\n");

		System.out.println("Back: \n" + historic.listBackAll());

		System.out.println("Forward: \n" + historic.listForwardAll());


		//Faz-se um back
		historic.back();

		//As pilhas
		System.out.println("As pilhas depois do back:\n");

		System.out.println("Back: \n" + historic.listBackAll());

		System.out.println("Forward: \n" + historic.listForwardAll());

		System.out.println("A accao corrente eh:");

		System.out.println(historic.currentAction());

		//Faz-se o forward
		historic.forward();

		//As pilhas
		System.out.println("As pilhas depois do forward:\n");

		System.out.println("Back: \n" + historic.listBackAll());

		System.out.println("Forward: \n" + historic.listForwardAll());

		System.out.println("A accao corrente eh:");

		System.out.println(historic.currentAction());

		
		
		//Nova situacao 2
		historic = new BackForwardManager(6);

		//Nao se deve conseguir forward nem back
		System.out.println("Forward: " + historic.forward());
		System.out.println("Back: " +historic.back());

		//regista-se uma accao
		goToResource(visitD1R1, historic);
		
		
		System.out.println();
		//Nao se deve conseguir forward mas um back
		System.out.println("Forward: " + historic.forward());
		System.out.println("Back: " + historic.back());
		
		//feito o back a accao corrente eh nula! (e nao rebenta)!!!!
		System.out.println(historic.currentAction());


		//Nova situacao 3
		
		historic = new BackForwardManager(6);
		
		
		goToResource(visitD1R1, historic);
		goToResource(visitD1R2, historic);
		goToResource(visitD1R3, historic);
		goToResource(visitD2R1, historic);
		goToResource(visitD2R2, historic);
		goToResource(visitD1R4, historic);
		goToResource(visitD2R3, historic);
		goToResource(visitD3R1, historic);
		goToResource(visitD3R2, historic);
		
		
		
		System.out.println("As pilhas depois das accoes iniciais:\n");

		System.out.println("Back: \n" + historic.listBackAll());

		System.out.println("Forward: \n" + historic.listForwardAll());


		
		//usar o skipBack
		
		historic.skipBack();
		
		System.out.println("As pilhas depois do skipBack:\n");

		System.out.println("Back: \n" + historic.listBackAll());

		System.out.println("Forward: \n" + historic.listForwardAll());
		
		
		//as que podemos fazer no mesmo dominio
		System.out.println("Back pilha dominio B: " + historic.listBackActionsSameDomain());
		
		System.out.println("forward pilha dominio B: " + historic.listForwardActionsSameDomain());
		
		
		//uso o skipForward
		System.out.println("skipForward: " + historic.skipForward());
		
		System.out.println();
		
		//Regista-se uma nova accao
		goToResource(visitD3R3, historic);
		
		System.out.println("As pilhas depois do novo registam ficam:\n");

		System.out.println("Back: \n" + historic.listBackAll());

		System.out.println("Forward: \n" + historic.listForwardAll());
		
		
		
		
	}

	private static void goToResource(RestAction visit, BackForwardManager historic) {

		historic.registerAction(visit);
	}

}
