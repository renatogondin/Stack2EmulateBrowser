/**
 * 
 * @author 
 *
 */
public class RestAction {

	
	//NAO SE ESQUECA DO @requires SEMPRE QUE NECESSARIO
	private Action action;
	private String domain;
	private String resource;
	/**
	 * 
	 * @param action
	 * @param domain
	 * @param resource
	 */
	
	public RestAction(Action action, String domain, String resource) {
		this.action = action;
		this.domain = domain;
		this.resource = resource;
		
	}
	
	/**
	 * 
	 * @return
	 */
	public Action getAction() {
		return this.action;
	}

	
	/**
	 * 
	 * @return
	 */
	public String getResource() {
		return this.resource;
	}
	

	/**
	 * 
	 * @return
	 */
	public String getDomain() {
		return this.domain;
	}


	/**
	 * 
	 */
	public String toString() {
		return this.getAction().toString() + " " + this.domain + "/" + this.resource;
	}
	
	
	
}
