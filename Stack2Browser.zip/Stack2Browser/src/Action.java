/**
 * 
 * Enumerado com os verbos das accoes Rest
 * 
 * @author andresouto
 *
 */
public enum Action {

	PUT,
	POST,
	DELETE,
	GET;
	
	
}
