
/**
 * 
 * @author 
 *
 * @param <E>
 */
public class ArrayStack<E>  {

	//NAO SE ESQUECA DO @requires SEMPRE QUE NECESSARIO

	/**
	 * 
	 */
	public static final int DEFAULT_CAPACITY = 10;
	private E[] vetor;
	private int size;
	
	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	public ArrayStack () {
		this.vetor = (E[]) new Object[DEFAULT_CAPACITY];
		this.size = 0;
	}


	/**
	 * 
	 * @param n
	 */
	@SuppressWarnings("unchecked")
	public ArrayStack (int n) {
		this.vetor = (E[]) new Object[n];
		this.size = 0;
	}

	/**
	 * 
	 * @return
	 */
	public int capacity() {
		return this.vetor.length;
	}

	
	/**
	 * 
	 */
	public void clear () {
		for(int i = 0; i < this.vetor.length; i++) {
			this.vetor[i] = null;
		}
		this.size = 0;
	}

	/**
	 * 
	 * @return
	 */
	public E peek () {
		return (this.size) == 0 ? null : this.vetor[this.size -1];
	}

	/**
	 * 
	 * @param e
	 */
	public void push (E e) {
		if(this.size == this.vetor.length) {
			for(int i = 0; i < this.vetor.length - 1; i++) {
				this.vetor[i] = this.vetor[i + 1];
			}
			this.size -= 1;
		}
		this.vetor[this.size] = e;
		this.size += 1;
	}


	/**
	 * 
	 * @return
	 */
	public E pop () {
		if(this.size == 0) {
			return null;
		}
		E elem = this.vetor[this.size - 1];
		this.vetor[this.size - 1] = null;
		this.size -= 1;
		return elem;
	}

	/**
	 * 
	 * @return
	 */
	public int size () {
		return this.size;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isEmpty () {
		return this.size == 0;
	}

	/**
	 * 
	 */
	public String toString () {
		StringBuilder sb = new StringBuilder();
		if(this.isEmpty()) {
			return "";
		}
		for(int i = this.vetor.length - 1; i >= 0; i--) {
			if(this.vetor[i] != null) {
				sb.append(this.vetor[i].toString());
				sb.append("\n");
			}
		}
		return sb.toString();
	}


	/**
	 * 
	 * @return
	 */
	public ArrayStack<E> copy() {
		if(this.isEmpty()) {
			return null;
		}
		ArrayStack<E> copia = new ArrayStack<E>(this.capacity());
		for(int i = 0; i < copia.vetor.length; i++) {
			copia.vetor[i] = this.vetor[i];
		}
		copia.size = this.size;
		return copia;
	}


	/**
	 * 
	 * @param other
	 * @return
	 */
	public boolean isEqual(ArrayStack<E> other) {
		boolean b = true;
		if(this.size != other.size()) {
			return false;
		}
		if(this.capacity() != other.capacity()) {
			return false;
		}
		for(int i = 0; i < this.size(); i++) {
			if(this.vetor[i] == null && this.vetor[i] != null) {
				return false;
			}if(this.vetor[i] != null && this.vetor[i] == null) {
				return false;
			}
			if(!this.vetor[i].equals(other.vetor[i])) {
				return false;
			}
		}
		return b;
	}

}