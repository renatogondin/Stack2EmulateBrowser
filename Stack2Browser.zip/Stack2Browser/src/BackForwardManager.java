
/**
 * 
 * @author 
 *
 */
public class BackForwardManager {


	//NAO SE ESQUECA DO @requires SEMPRE QUE NECESSARIO
	private ArrayStack<RestAction> backward;
	private ArrayStack<RestAction> frontward;
	/**
	 * 
	 */
	public BackForwardManager() {
		this.backward = new ArrayStack<RestAction>();
		this.frontward = new ArrayStack<RestAction>();
	}

	/**
	 * 
	 * @param capacity
	 */
	public BackForwardManager(int capacity) {
		this.backward = new ArrayStack<RestAction>(capacity);
		this.frontward = new ArrayStack<RestAction>(capacity);
	}

	/**
	 * 
	 * @return
	 */
	public int capacity() {
		return this.backward.capacity();
	}

	/**
	 * 
	 * @param action
	 */
	public void registerAction (RestAction action) {
		this.backward.push(action);
		this.frontward.clear();
	}

	
	/**
	 * 
	 * @return
	 */
	public RestAction currentAction() {
		if(this.backward.isEmpty()) {
			return null;
		}
		return this.backward.peek();
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean back() {
		if(this.backward.isEmpty()) {
			return false;
		}else {
			this.frontward.push(this.backward.pop());
			return true;
		}
	}


	/**
	 * 
	 * @return
	 */
	public boolean skipBack() {
		if(this.backward.isEmpty()) {
			return false;
		}
		this.frontward.push(this.backward.pop());
		this.frontward.push(this.backward.pop());
		return this.backward.isEmpty() ? false : true;
	}

	/**
	 * 
	 * @return
	 */
	public boolean forward() {
		if(this.frontward.isEmpty()) {
			return false;
		}else {
			this.backward.push(this.frontward.pop());
			return true;
		}
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean skipForward() {
		if(this.frontward.isEmpty()) {
			return false;
		}else {
			this.backward.push(this.frontward.pop());
			this.backward.push(this.frontward.pop());
			return this.backward.isEmpty() ? false : true;
		}
	}


	/**
	 * 
	 * @return
	 */
	public String listBackAll() {
		if(this.backward.isEmpty()) {
			return "vazia\n";
		}
		return this.backward.toString();
	}

	/**
	 * 
	 * @return
	 */
	public String listForwardAll() {
		if(this.frontward.isEmpty()) {
			return "vazia\n";
		}
		return this.frontward.toString();
	}

	/**
	 * 
	 * @return
	 */
	public String listBackActionsSameDomain() {
		if(this.backward.isEmpty()) {
			return "vazia\n";
		}
		ArrayStack<RestAction> a = this.backward.copy();
		ArrayStack<RestAction> b = new ArrayStack<RestAction> (this.capacity());
		ArrayStack<RestAction> c = new ArrayStack<RestAction> (this.capacity());
		String dominio = this.backward.peek().getDomain();
		while(!a.isEmpty()) {
			if(a.peek().getDomain().equals(dominio)) {
				b.push(a.pop());
			}else {
				c.push(a.pop());
			}
		}
		while(!b.isEmpty()) {
			a.push(b.pop());
		}
		return a.toString();
	}



	/**
	 * 
	 * @return
	 */
	public String listForwardActionsSameDomain() {
		if(this.backward.isEmpty()) {
			return "vazia\n";
		}if(this.frontward.isEmpty()) {
			return "vazia\n";
		}
		ArrayStack<RestAction> a = this.frontward.copy();
		ArrayStack<RestAction> b = new ArrayStack<RestAction> (this.capacity());
		ArrayStack<RestAction> c = new ArrayStack<RestAction> (this.capacity());
		String dominio = this.backward.peek().getDomain();
		while(!a.isEmpty()) {
			if(a.peek().getDomain().equals(dominio)) {
				b.push(a.pop());
			}else {
				c.push(a.pop());
			}
		}
		while(!b.isEmpty()) {
			a.push(b.pop());
		}
		return a.toString();

	}




}
