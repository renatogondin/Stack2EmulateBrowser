import static org.junit.Assert.*;

import org.junit.Test;

public class BackForwardManagerForwardNextAction {

	private BackForwardManager paraTeste;
	
	private  RestAction action1 = new RestAction(Action.PUT, "page1", "resource1");
	private  RestAction action2 = new RestAction(Action.GET, "page1", "resource2");
	
	private  RestAction action4 = new RestAction(Action.GET, "page2", "resource2");


	@Test
	public void teste1() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		
		boolean expected = true;
		
		paraTeste.back();
		
		boolean actual = paraTeste.forward();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void teste2() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		
		boolean expected = true;
		paraTeste.back();
		boolean actual = paraTeste.forward();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test3() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.back();
		
		paraTeste.registerAction(action4);
		
		
		boolean expected = false;
		boolean actual = paraTeste.forward();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void test4() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		
		
		boolean expected = false;
		boolean actual = paraTeste.forward();
		
		assertEquals(expected, actual);
	}
	
	
	@Test
	public void test5() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.back();
		paraTeste.back();
		paraTeste.forward();
		
		
		boolean expected = true;
		boolean actual = paraTeste.forward();
		
		assertEquals(expected, actual);
	}
	
}