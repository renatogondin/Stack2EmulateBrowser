import static org.junit.Assert.*;

import org.junit.Test;

public class BackForwardManagerBackLastAction {

	private BackForwardManager paraTeste;

	private  RestAction action1 = new RestAction(Action.PUT, "page1", "resource1");
	private  RestAction action2 = new RestAction(Action.GET, "page1", "resource2");


	//CORRIGIR TESTES

	@Test
	public void teste1() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.back();

		boolean  expected = false;
		boolean actual = paraTeste.back();

		assertEquals(expected, actual);
	}

	@Test
	public void teste2() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);

		boolean expected = true;
		boolean actual = paraTeste.back();

		assertEquals(expected, actual);
	}

	@Test
	public void test3() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.back();


		boolean expected = true;
		boolean actual = paraTeste.back();

		assertEquals(expected, actual);
	}

	@Test
	public void test4() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.back();
		paraTeste.back();


		boolean expected = false;
		boolean actual = paraTeste.back();

		assertEquals(expected, actual);
	}


	@Test
	public void test5() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.back();
		paraTeste.back();
		paraTeste.forward();


		boolean expected = true;
		boolean actual = paraTeste.back();

		assertEquals(expected, actual);
	}



}