
import static org.junit.Assert.*;

import org.junit.Test;

public class BackForwardManagerSkipBackBoolean {

	private BackForwardManager paraTeste;

	private  RestAction action1 = new RestAction(Action.PUT, "page1", "resource1");
	private  RestAction action2 = new RestAction(Action.GET, "page1", "resource2");

	private  RestAction action3 = new RestAction(Action.PUT, "page2", "resource1");
	private  RestAction action4 = new RestAction(Action.GET, "page2", "resource2");



	@Test
	public void teste1() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.registerAction(action3);
		paraTeste.registerAction(action4);


		boolean actual = paraTeste.skipBack();

		boolean expected = true;

		assertEquals(expected, actual);
	}

	@Test
	public void teste2() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);

		boolean expected = false;

		boolean actual = paraTeste.skipBack();

		assertEquals(expected, actual);
	}

	@Test
	public void teste3() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.registerAction(action3);

		boolean expected = false;
		
		paraTeste.back();
		boolean actual = paraTeste.skipBack();


		assertEquals(expected, actual);
	}

	@Test
	public void test4() {
		paraTeste = new BackForwardManager();


		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.registerAction(action3);

		
		paraTeste.back();
		paraTeste.forward();
		


		boolean expected = true;
		boolean actual = paraTeste.skipBack();

		assertEquals(expected, actual);
	}


	
}