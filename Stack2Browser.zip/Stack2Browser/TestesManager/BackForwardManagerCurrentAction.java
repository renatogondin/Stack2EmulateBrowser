import static org.junit.Assert.*;

import org.junit.Test;

public class BackForwardManagerCurrentAction {

	private BackForwardManager paraTeste;
	
	private  RestAction action1 = new RestAction(Action.PUT, "page1", "resource1");
	private  RestAction action2 = new RestAction(Action.GET, "page1", "resource2");
	
	private  RestAction action4 = new RestAction(Action.GET, "page2", "resource2");


	@Test
	public void teste1() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		
		String expected = "PUT page1/resource1";
		
		
		String actual = paraTeste.currentAction().toString();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void teste2() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		
		String expected = "PUT page1/resource1";
		paraTeste.back();
		String actual = paraTeste.currentAction().toString();
		
		assertEquals(expected, actual);
	}

	@Test
	public void test3() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.back();
		
		paraTeste.registerAction(action4);
		
		
		String expected = "GET page2/resource2";
		String actual = paraTeste.currentAction().toString();
		
		assertEquals(expected, actual);
	}
	
	@Test(expected=NullPointerException.class)
	public void test4() {
		paraTeste = new BackForwardManager();

		
		
		String expected = null;
		String actual = paraTeste.currentAction().toString();
		
		assertEquals(expected, actual);
	}
	
	
	@Test
	public void test5() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.back();
		paraTeste.back();
		paraTeste.forward();
		
		
		String expected = "PUT page1/resource1";
		String actual = paraTeste.currentAction().toString();
		
		assertEquals(expected, actual);
	}
	
}