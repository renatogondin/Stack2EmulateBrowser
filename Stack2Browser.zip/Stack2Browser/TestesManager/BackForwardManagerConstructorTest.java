import static org.junit.Assert.*;

import org.junit.Test;

public class BackForwardManagerConstructorTest {

	private BackForwardManager paraTeste;

	@Test
	public 	void testBackForwardManager() {
		paraTeste = new BackForwardManager();
		
		int expected = ArrayStack.DEFAULT_CAPACITY;
		int actual = paraTeste.capacity();
		
		assertEquals(expected, actual);
	}
	
	
	@Test
	public void testBackForwardManager2() {
		paraTeste = new BackForwardManager();
		
		String expected ="vazia\n";
		String actual = paraTeste.listBackAll();
		
		assertEquals(expected, actual);
	}

	
	@Test
	public void testBackForwardManager3() {
		paraTeste = new BackForwardManager();
		
		String expected ="vazia\n";
		String actual = paraTeste.listForwardAll();
		
		assertEquals(expected, actual);
	}
	
	public void testBackForwardManagerInt() {
		paraTeste = new BackForwardManager(3);
		
		int expected = 3;
		int actual = paraTeste.capacity();
		
		assertEquals(expected, actual);
	}
	
	
	@Test
	public void testBackForwardManagerInt2() {
		paraTeste = new BackForwardManager(3);
		
		String expected ="vazia\n";
		String actual = paraTeste.listBackAll();
		
		assertEquals(expected, actual);
	}

	
	@Test
	public void testBackForwardManagerInt3() {
		paraTeste = new BackForwardManager(3);
		
		String expected ="vazia\n";
		String actual = paraTeste.listForwardAll();
		
		assertEquals(expected, actual);
	}

}
