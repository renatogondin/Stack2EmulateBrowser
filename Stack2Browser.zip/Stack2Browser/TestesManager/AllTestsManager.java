import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({  
	BackForwardManagerBackLastAction.class,
	BackForwardManagerConstructorTest.class,
	BackForwardManagerCurrentAction.class,
	BackForwardManagerForward.class,
	BackForwardManagerListAllBackActions.class,
	BackForwardManagerListAllForwardActions.class,
	BackForwardManagerListForwardActionsSameDomain.class,
	BackForwardManagerListAllBackActionsSameDomain.class,
	BackForwardManagerSkipForwardBoolean.class,
	BackForwardManagerSkipBackBoolean.class,
	BackForwardManagerRegisterAction.class,
})

public class AllTestsManager {

}