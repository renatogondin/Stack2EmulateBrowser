import static org.junit.Assert.*;

import org.junit.Test;


public class BackForwardManagerRegisterAction {

	private BackForwardManager paraTeste;
	
	private  RestAction action1 = new RestAction(Action.PUT, "page1", "resource1");
	private  RestAction action2 = new RestAction(Action.GET, "page1", "resource2");
	
	private  RestAction action3 = new RestAction(Action.PUT, "page2", "resource1");
	private  RestAction action4 = new RestAction(Action.GET, "page2", "resource2");
	private  RestAction action5 = new RestAction(Action.GET, "page2", "resource3");
	private  RestAction action6 = new RestAction(Action.GET, "page2", "resource4");


	@Test
	public void testBackForwardManager() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		
		String expected = "PUT page1/resource1\n";
		String actual = paraTeste.listBackAll();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void testBackForwardManager1() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		
		String expected = "vazia\n";
		String actual = paraTeste.listForwardAll();
		
		assertEquals(expected, actual);
	}

	@Test
	public void testBackForwardManager2() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		
		String expected = "GET page1/resource2\n" + 
				"PUT page1/resource1\n";
		String actual = paraTeste.listBackAll();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void testBackForwardManagerF2() {
		paraTeste = new BackForwardManager();

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		
		String expected = "vazia\n";
		String actual = paraTeste.listForwardAll();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void testBackForwardManager3() {
		paraTeste = new BackForwardManager(3);

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.registerAction(action3);
		
		String expected = "PUT page2/resource1\n" + 
				"GET page1/resource2\n" + 
				"PUT page1/resource1\n";
		String actual = paraTeste.listBackAll();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void testBackForwardManagerF3() {
		paraTeste = new BackForwardManager(3);

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.registerAction(action3);
		
		String expected = "vazia\n";
		String actual = paraTeste.listForwardAll();
		
		assertEquals(expected, actual);
	}
	
	@Test
	public void testBackForwardManager4() {
		paraTeste = new BackForwardManager(3);

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.registerAction(action3);
		paraTeste.registerAction(action4);
		paraTeste.registerAction(action5);
		paraTeste.registerAction(action6);
		
		String expected = "GET page2/resource4\n" + 
		        "GET page2/resource3\n" + 
		        "GET page2/resource2\n";
		String actual = paraTeste.listBackAll();
		
		assertEquals(expected, actual);
	}
	
	
	@Test
	public void testBackForwardManagerF4() {
		paraTeste = new BackForwardManager(3);

		
		paraTeste.registerAction(action1);
		paraTeste.registerAction(action2);
		paraTeste.registerAction(action3);
		paraTeste.registerAction(action4);
		paraTeste.registerAction(action5);
		paraTeste.registerAction(action6);
		
		String expected = "vazia\n";
		String actual = paraTeste.listForwardAll();
		
		assertEquals(expected, actual);
	}
	
	
}
