
import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class RestActionTest {

	private RestAction xpto;
	

	@Test
	public void testGetAction() {
		this.xpto = new RestAction(Action.GET, "teste", "noMeioDoTeste");		
		Action expected = Action.GET;
		Action actual = xpto.getAction();
		
		assertEquals(expected, actual);
	}

	@Test
	public void testGetResource() {
		this.xpto = new RestAction(Action.GET, "teste", "noMeioDoTeste");		
		String expected = "noMeioDoTeste";
		String actual = xpto.getResource();
		
		assertEquals(expected, actual);
	}

	@Test
	public void testGetPage() {
		this.xpto = new RestAction(Action.GET, "teste", "noMeioDoTeste");		
		String expected = "teste";
		String actual = xpto.getDomain();
		
		assertEquals(expected, actual);
	}

	@Test
	public void testToString() {
		this.xpto = new RestAction(Action.GET, "teste", "noMeioDoTeste");		
		String expected = "GET teste/noMeioDoTeste";
		String actual = xpto.toString();
		
		assertEquals(expected, actual);
	}

}
